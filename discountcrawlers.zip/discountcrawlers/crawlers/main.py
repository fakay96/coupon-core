import asyncio
import json
from pathlib import Path
from utils.embedding import embed_text, save_embedding

DEALS_PATH = Path(__file__).parent / "discounts.json"

async def main():
    if not DEALS_PATH.exists():
        raise FileNotFoundError(f"{DEALS_PATH} not found—run your crawler first.")
    # Load the raw deals
    deals = json.loads(DEALS_PATH.read_text(encoding="utf-8"))
    # Serialize as a single string
    ctx = json.dumps(deals, ensure_ascii=False)
    # Get the embedding (you can tweak task_type if you like)
    print("Computing embedding for", DEALS_PATH)
    vec = await embed_text(ctx, task_type="SEMANTIC_SIMILARITY")
    # This will write `discounts.emb.json` right next to your discounts.json
    save_embedding(vec, DEALS_PATH)
    print("Saved embedding to", DEALS_PATH.with_suffix(".emb.json"))

if __name__ == "__main__":
    asyncio.run(main())
