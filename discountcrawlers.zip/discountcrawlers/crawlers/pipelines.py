"""discountscraper.pipelines
===================================
Item pipeline definition with strong typing, docstrings, and utilities
extracted into helper functions.

The pipeline converts *price‑like* fields from strings to numeric values,
normalises discount percentages, and finally stamps a scrape timestamp.

Separation‑of‑concerns:
    * **Parsing / extraction** happens in spiders and helper functions.
    * **Normalisation / cleaning** lives here in the pipeline.
    * **Persistence** (database, file, etc.) can be implemented downstream
      in a dedicated feed exporter or extra pipeline stage.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping, MutableMapping, Protocol

from itemadapter import ItemAdapter

# Local imports
from .utils.price import (
    parse_discount_percentage,
    parse_euro_price,
)


class SupportsMapping(Protocol):
    """Protocol modelling Scrapy items and dataclasses like DiscountData."""

    def items(self) -> Any:  # pragma: no cover
        ...


class DiscountPipeline:
    """Clean and normalise scraped discount items.

    The pipeline is enabled via the ``ITEM_PIPELINES`` Scrapy setting.
    """

    def process_item(
        self,
        item: Any,
        spider: "scrapy.Spider",  # type: ignore[name-defined]  # Scrapy injects Spider dynamically
    ) -> Any:
        adapter = ItemAdapter(item)

        # ----- Price parsing -------------------------------------------------
        for price_field in ("sale_price", "original_price"):
            parsed = parse_euro_price(adapter.get(price_field))
            adapter[price_field] = parsed

        # ----- Discount % parsing -------------------------------------------
        adapter["discount_percentage"] = parse_discount_percentage(
            adapter.get("discount_percentage")
        )

        # ----- Timestamp -----------------------------------------------------
        adapter["timestamp"] = datetime.utcnow().isoformat()

        return item
