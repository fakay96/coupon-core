"""
gemini_chat.py

Wrapper for Google Generative Language API (Gemini Flash chat).
Provides an async `chat` function to send a user prompt and receive the assistant response.
"""
from __future__ import annotations
import os
import httpx

# Ensure your Gemini API key is set in the environment:
_GEMINI_KEY = os.getenv("GEMINI_API_KEY")
if not _GEMINI_KEY:
    raise RuntimeError("Set GEMINI_API_KEY environment variable before using gemini_chat")

# Endpoint for the Generative Language API chat model (Gemini Flash / Bison)
_CHAT_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "chat-bison-001:generateMessage"
    f"?key={_GEMINI_KEY}"
)
# Headers for JSON payload
_HEADERS = {"Content-Type": "application/json"}

async def chat(prompt: str) -> str:
    """
    Send a user prompt to the Gemini Flash chat model and return the assistant's reply.

    Args:
        prompt: The user message to send.

    Returns:
        The assistant's response text.
    """
    payload = {
        "model": "chat-bison-001",  # or replace with your desired Gemini chat model
        "prompt": {
            "messages": [
                {"author": "user", "content": prompt}
            ]
        }
    }
    async with httpx.AsyncClient(http2=True, timeout=60) as client:
        response = await client.post(_CHAT_URL, headers=_HEADERS, json=payload)
        response.raise_for_status()
        data = response.json()

    # Parse the first candidate response
    candidates = data.get("candidates", [])
    if not candidates:
        raise RuntimeError("No response candidates returned from Gemini chat API")

    return candidates[0].get("content", "")
